/**
 * 
 */
package salles;

/**
 * @author Antoine Lavail
 *
 */

public class SalleNourrice extends Salle {
	
	// Constructeur par d�faut
	public SalleNourrice() {
		super();
	}

}
