package vues;

/**
 * Vue console, gérera l'affichage des données/ interaction client
 * 
 * @author mazen
 */

public class console {
	
	public console(){
		
		this.run();
	}

	public void run() {
		System.out.println("OK");
	}
	
}
