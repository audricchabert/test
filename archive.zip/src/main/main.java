package main;

import tests.SalleAtelierTest;
import vues.console;

public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new console();
	}

}
